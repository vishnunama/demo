import React, { useState, useContext } from 'react';
import SignupPopup from './SignupPopup'; // Import SignupPopup component
import carticon from "../Assets/icons/cart.svg";

import usericon from "../Assets/icons/user.svg"; // User icon for create account
import { ShopContext } from './ShopContext';
import { Link } from 'react-router-dom';
import logo from "../Assets/logo/logo.jpg";
import { FiChevronDown } from 'react-icons/fi'; // Dropdown arrow icon
import { FaSignOutAlt, FaUser } from 'react-icons/fa'; // Logout icon
import profile from "../Assets/logo/profile.png"
import "./Header.css"
import DropDown from './DropDown';
import { IoMenu } from 'react-icons/io5';


const Header = () => {

  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };


  const { getTotalCartITems } = useContext(ShopContext);
  const [isPopupOpen, setPopupOpen] = useState(false); // State for popup visibility
  const [user, setUser] = useState(null); // User state to store email

  const handleOpenPopup = () => setPopupOpen(true);
  const handleClosePopup = () => setPopupOpen(false);

  const handleLogin = (email) => {
    setUser(email); // Set user email after successful login/signup
  };

  const handleLogout = () => {
    setUser(null); // Reset user state on logout
  };

  const handleSignup = (email) => {
    setUser(email); // Set the user email after signup
  };

  const getUserName = (email) => {
    return email.split('@')[0]; // Extract username from email
  };

  return (
    <>
      <header className="header">
        <div className="container container-full">
          
          <nav className="header-inner flx-between">
            <div>
      <button style={{fontSize:"25px"}} className="btn-primary" onClick={toggleSidebar}>
        < IoMenu />

      </button>
      <DropDown isOpen={isSidebarOpen} toggleSidebar={toggleSidebar} />
    </div>

            



            {/* Logo Start */}
            <Link to='/'>
              <div className="logo">
                
                <a className="link white-version">
                  <img style={{borderRadius:"20px"}} className='image-logo-in' src={logo} alt="Logo" />
                </a>
                
              </div>
            </Link>
            {/* Logo End */}

            {/* Menu Start */}
            <div className="header-menu d-lg-block d-none">
              <ul className="nav-menu flx-align">
                <li className="nav-menu__item has-submenu">
                  <span className="nav-menu__link">
                    <Link to="/">Home</Link> <FiChevronDown className="nav-icon" />
                  </span>
                </li>
                <li className="nav-menu__item has-submenu">
                  <span className="nav-menu__link">
                    <Link to="/PrivacyPolicy">Privacy Policy</Link>
                  </span>
                </li>
                <li className="nav-menu__item has-submenu">
                  <span className="nav-menu__link">
                    <Link to="/RefundPolicy">Refund Policy</Link>
                  </span>
                </li>
                <li className="nav-menu__item has-submenu">
                  <span className="nav-menu__link">
                    Product <FiChevronDown className="nav-icon" />
                  </span>
                  <ul className="nav-submenu">
                    <li className="nav-submenu__item">
                      <Link to="/all_Product">
                        <a className="nav-submenu__link">All Products</a>
                      </Link>
                    </li>
                    <li className="nav-submenu__item">
                      <Link to="/product/1">
                        <a className="nav-submenu__link">Product Details</a>
                      </Link>
                    </li>
                  </ul>
                </li>
              </ul>
            </div>
            {/* Menu End */}

            {/* Header Right Start */}
            <div className="header-right flx-align">

              
              

              {/* Light Dark Mode */}
              

              {/* User/Account Section */}
              {user ? (
                <div className="user-dropdown">
                  <button className="btn btn-main pill">
                    <img src={profile} alt="User Icon" className="user-icon" /> {getUserName(user)} <FiChevronDown />
                  </button>
                  <div className="dropdown-menu">
                    <button style={{gap:"10px"}} className="dropdown-item1"> Profile</button>
                    <button className="dropdown-item">Purchases</button>
                    <button className="dropdown-item">Transactions</button>
                    <button className="dropdown-item" onClick={handleLogout}>
                      <FaSignOutAlt className="logout-icon" /> Logout
                    </button>
                  </div>
                </div>
              ) : (
                <div className="header-right__inner gap-3 flx-align d-lg-flex ">
                  <button  className="btn btn-main pill" onClick={handleOpenPopup}>
                   
                    <div className='create-account'>Create Account <FiChevronDown /></div>
                    
                  </button>
                </div>
              )}

              {/* Cart Icon */}
              <Link to="/cart" className="header-right__button cart-btn position-relative">
                <img src={carticon} alt="Cart Icon" className="white-version" />
                <span className="qty-badge font-12">{getTotalCartITems()}</span>
              </Link>

              
              
            </div>
            {/* Header Right End */}
          
          </nav>
        </div>
      </header>

      {/* SignupPopup Component */}
      <SignupPopup isOpen={isPopupOpen} onClose={handleClosePopup} onSignup={handleSignup} />
    </>
  );
};

export default Header;
